/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testbj;

/**
 *
 * @author kunal
 */
import java.util.ArrayList;
import java.util.LinkedList;


public class Dealer  {
private LinkedList<Card> card;
   
public void dealCard(Card c) {
        Card[] cards = new Card[1];
        for (int i = 0; i<cards.length; i++){
            cards[i] = c;
            c.setRank(1);
            c.setSuits("");             
            //System.out.println(c);     
        }
}
}