/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Peter
 * @author Kunal
 */
package testbj;


import java.util.Scanner;


public class TestBJ 
{
    
public static void main(String[] args)
    {      
       int money;
       String betCheck;
       boolean win;
       money = 200;
       int bet;
       while(true){
           System.out.print("\n" + "You have " + money + " money left!");
           
           do{
               System.out.print("\n" + "How much would you like to bet? (if you enter 0 game will end)");
               
               Scanner scan = new Scanner(System.in);
               while(!scan.hasNextInt()) {
                   System.out.print("That is not a number Please try again!");
                    scan.next();
                }
               bet = scan.nextInt();
               
               if(bet < 0 || bet > money){
                   System.out.print("Please re-enter your bet must be between 0 and " + money +"\n");
               }
           }
           while(bet <0 || bet > money);
           
           if(bet == 0){
               System.out.print("\n" + "Have a nice day enjoy your $" + money);
               break;               
           }
           win = playGame();
           
                if(win){
                    money = money + bet;
                }
                else{
                    money = money - bet;
                }
                if(money == 0 ){
                    System.out.print("you are out of money!!! GAME OVER.");
                    break;
                }     
       }
        
    }
    static boolean playGame() {
        int sum = 0;
        int dealTotal = 0;
        
        Dealer dealer = new Dealer();
        
        //dealer hand
        Hand dealHand = new Hand();
        //Hand dealHand2 = new Hand();
        Card d = new Card(1,"");
        //Card d2 = new Card(1,"");
        dealer.dealCard(d);
        //dealer.dealCard(d2);
        System.out.println("Dealers first card:");
        dealHand.addCard(d);

        //dealHand2.addCard(d2);
        dealTotal+= dealHand.getHandValue();
        System.out.println("\n" + "Total hand value of Dealer: " + dealTotal);
        
        System.out.println("\n");
        
        //user hand
        Hand h = new Hand();
        Hand h2 = new Hand();
        
        Card c = new Card(1,"");
        Card c2 = new Card(1,"");
        
        dealer.dealCard(c);
        dealer.dealCard(c2);
        
        System.out.println("Users first 2 cards:");
        h.addCard(c);
        System.out.print(", ");
        h2.addCard(c2);
        
        sum+= h.getHandValue() + h2.getHandValue();
        System.out.println("\n" + "Total hand value of player: " + sum);
        
        if(sum == 21){
            System.out.println("WOW you got a blackjack! you win this round");
            return true;
        }
        
        while(true){
            System.out.println("Would you like to Hit (h) or Stand (s)");
            
            Scanner horS = new Scanner(System.in);
            String str = horS.next();
            char hitorstand = str.charAt(0);
            
            if(hitorstand == 's'){
                break;
            }
            else{
                Hand h3 = new Hand();
                Card c3 = new Card(1,"");
                dealer.dealCard(c3);
                h3.addCard(c3);
                sum+= h3.getHandValue();
                if(sum > 21){
                    break;
                }
                System.out.println("\n" + "Total hand value of player: " + sum);
            }
        }
        //dealer hand
        Hand dealHand2 = new Hand();
        //Hand dealHand2 = new Hand();
        Card d2 = new Card(1,"");
        //Card d2 = new Card(1,"");
        dealer.dealCard(d2);
        //dealer.dealCard(d2);
        System.out.println("\n" + "Dealers second card:");
        //System.out.println("\n");
        dealHand2.addCard(d2);
        
        //dealHand2.addCard(d2);
        dealTotal+= dealHand2.getHandValue();
        System.out.println("Dealers new total: " + dealTotal);
        
        if(sum > 21){
            System.out.println("Oh no! you have went bust and lose this round!");
            return false;
        }
        else if(dealTotal == 21 && sum !=21){
            return false;
        }
        else if(sum < dealTotal && dealTotal < 22){
            System.out.print("Dealer had a greater value and therefore you lose");
            return false;
        }
        else{
            System.out.print("\n" + "you win you had the better hand this round!" + "\n");
            return true;
        }      
    }
}

