/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testbj;

/**
 *
 * @author kunal
 * @author Peter
 */
import java.util.LinkedList;

public class Hand {
                


private LinkedList<Card> hand;
private int handValue;
private int count;


public Hand() {

        hand = new LinkedList<>();
        handValue = 0;
        count = 0;  
    }

// passes Card c as argument

public void addCard(Card c)   {
    if(c.getValue()>10){     //ensures that King,Queen equal 10 like Jack 
        this.hand.add(c);
        hand.add(c);
        handValue += 10;
        System.out.print(c);
    }
    else{
    this.hand.add(c);
    hand.add(c);
    handValue += c.getValue();
    System.out.print(c);
   
    }
}

// method to return the value to the main class and updates addCard
public int getHandValue()
{
    return handValue;
}



}
