/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testbj;

/**
 *
 * @author kunal
 */
import java.util.Random; 
public class Card 
{
  private String suit;
  private int rank;
  private int value;
public static final String[] SUITS={"diamonds","clubs","spades","hearts"};
public static final int[] ranks = {1, 2, 3, 4, 5, 6, 7 , 8, 9, 10, 11, 12, 13};
     Random r= new Random(); 
    int randomValue=r.nextInt(SUITS.length); //randomizes the suit
    int randomValue2 = r.nextInt(ranks.length); // randomizes the rank
    
    
 public Card(int Rank, String Suit) {       
        rank = Rank;
        suit = Suit;
}   
  
public String getSuits() {
    suit = SUITS[randomValue];  //is used as an index to randomly pick one suit
    return suit;
}
    
public void setSuits(String suit) {
    suit = SUITS[randomValue]; // same as the other randomValue
    this.suit = suit;

}

public String getRankasString() { //converts the Ranks into names
    switch(rank){
       case 1:  return "Ace";
       case 2:  return "2";
       case 3:  return "3";
       case 4:  return "4";
       case 5:  return "5";
       case 6:  return "6";
       case 7:  return "7";
       case 8:  return "8";
       case 9:  return "9";
       case 10:  return "10";
       case 11:  return "Jack";
       case 12:  return "Queen";
       case 13:  return "King";
       default:  return "";
    }
}
   
public int getRank() {
    rank = ranks[randomValue2];  
    return rank;
}

public void setRank(int rank) {
    rank = ranks[randomValue2];  
    this.rank = rank;
}

public int getValue() { // Reconverts rank into a numerical value for a single card
    value = getRank();
    return value;
}


public @Override String toString()
{
   return  getRankasString()  + " of " + this.suit;
}
      
    
}
